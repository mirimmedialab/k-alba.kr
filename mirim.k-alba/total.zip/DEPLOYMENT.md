# K-ALBA 배포 가이드 (5분 완성)

## 🚀 빠른 배포 — 5단계

### 1. 압축 해제 + 의존성 설치
```bash
unzip k-alba-final-v2.2.zip
cd k-alba-final
npm install
```

### 2. 환경변수 설정
```bash
cp .env.example .env.local
# .env.local 파일을 열어서 실제 값 입력
```

필수 키 (최소):
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `KAKAO_REST_API_KEY`
- `NEXT_PUBLIC_KAKAO_MAP_JS_KEY`
- `RESEND_API_KEY`
- `NEXT_PUBLIC_SITE_URL`

### 3. Supabase 설정

#### 3-1. 마이그레이션 실행
```bash
# Supabase CLI
npx supabase link --project-ref YOUR_PROJECT_REF
npx supabase db push

# 또는 Dashboard > SQL Editor에서 supabase/migrations/ 12개 파일을
# 파일명 순서대로 직접 실행
```

#### 3-2. Storage 버킷 생성 (Dashboard > Storage)
- `staff-documents` (private)
- `partwork-documents` (private)
- `contract-pdfs` (private)
- `signatures` (private)

#### 3-3. Auth 설정 (Dashboard > Authentication)
- Site URL: `https://k-alba.kr`
- Redirect URLs: `https://k-alba.kr/auth/callback`

### 4. Vercel 배포
```bash
# Git 푸시
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_ORG/k-alba.git
git push -u origin main

# Vercel 자동 배포 (https://vercel.com에서 GitHub 연동)
# 또는 Vercel CLI:
npm i -g vercel
vercel --prod
```

Vercel에서 환경변수 설정 잊지 않기:
Dashboard > Settings > Environment Variables → `.env.local`의 모든 키 추가

### 5. 도메인 연결
```
가비아 DNS:
  k-alba.kr     CNAME    cname.vercel-dns.com
  www.k-alba.kr CNAME    cname.vercel-dns.com
```

---

## ✅ 배포 후 확인 사항

| 페이지 | URL | 확인 |
|---|---|---|
| 홈 | https://k-alba.kr | 다국어 환영 화면 표시 |
| 알바 검색 | https://k-alba.kr/jobs | 일자리 목록 (DB 연결 확인) |
| 학생 신청 | https://k-alba.kr/partwork | 비자별 안내 표시 |
| 담당자 포털 | https://k-alba.kr/staff/partwork | 로그인 필요 페이지 |
| 첫 admin 신청 | https://k-alba.kr/staff/register | 대학 검색 작동 |
| 시뮬레이터 | https://k-alba.kr/simulator/k-alba-simulator.html | 마스터 시뮬레이터 |

---

## 🛠 운영 시작 작업

### A. 첫 admin 직접 등록 (대학별 1회)

1. 학교에서 [/staff/register](https://k-alba.kr/staff/register) 신청
2. 운영팀이 5단계 검증 (도메인/공문/통화/홈페이지/직원증)
3. SQL로 첫 admin 활성화:

```sql
INSERT INTO university_staff (
  user_id, university_id, staff_name, staff_position,
  staff_email, department, role, is_active
)
VALUES (
  '<auth.users.id>',
  (SELECT id FROM universities WHERE name = '한양대학교'),
  '홍길동', '국제처장',
  'hong@hanyang.ac.kr', '국제처',
  'admin', true
);

UPDATE universities SET registered_at = now()
WHERE name = '한양대학교';
```

### B. 학교 도메인 화이트리스트 등록

```sql
UPDATE universities SET allowed_email_domains = ARRAY['hanyang.ac.kr', 'hanyang.kr']
WHERE name = '한양대학교';
```

전체 399개 대학은 점진적으로 등록. 자세한 SQL은 `docs/10_OPERATIONS_GUIDE.md` 참조.

---

## 📱 모바일 앱 (선택)

```bash
npm run cap:sync
npx cap open ios      # Xcode (App Store 심사용)
npx cap open android  # Android Studio (Google Play 심사용)
```

자세한 절차: `docs/04_CAPACITOR_MOBILE.md`

---

## 🆘 문제 발생 시

| 증상 | 해결 |
|---|---|
| `next build` 실패 | `npm install` 재실행, Node 18+ 사용 |
| Supabase 연결 안 됨 | `.env.local`의 URL/Key 확인 |
| RLS 차단 | `SUPABASE_SERVICE_ROLE_KEY`로 직접 INSERT |
| 카카오맵 미표시 | `NEXT_PUBLIC_KAKAO_MAP_JS_KEY` 도메인 등록 확인 |
| 이메일 미발송 | Resend API 한도 + 도메인 인증 확인 |

문의: support@k-alba.kr · 미림미디어랩(주)
