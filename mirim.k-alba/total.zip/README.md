# K-ALBA — 외국인 알바 매칭 + 유학생 시간제취업 신청 시스템

**한국에서 일하고 공부하는 모든 외국인을 위한 통합 디지털 인프라**

운영사: 미림미디어랩(주) · 대표: 남기환 · 도메인: [k-alba.kr](https://k-alba.kr)
빌드: 2026-04-26 · 라이선스: Proprietary

---

## 🎯 시스템 개요

K-ALBA는 한국에 체류하는 260만 외국인을 위한 두 가지 서비스를 제공합니다:

### 1. 알바 매칭 플랫폼
- WorkNet · AgriWork · 자체 등록 3개 소스 통합 (정규화된 9개 테이블)
- 비자별 (E-9, H-2, C-4, D-2, D-4 등) 자격 자동 판정
- 위치 기반 추천 (Kakao Map + 카카오/네이버 모빌리티 API)
- 다국어 지원 (한·영·중·일·베·미얀마·인니)

### 2. 외국인 유학생 시간제취업 시스템
- **학생 측**: 6종 서류 업로드 + 자동 시간제취업확인서 생성 (붙임 4-1 양식)
- **국제처 담당자 측**: 신청서 검토 · 디지털 서명 · 승인 워크플로
- 출입국관리법 시행령 자동 적용 (TOPIK 급수 + 인증대학 보너스)
- KakaoTalk 표준근로계약서 챗봇 연동 (법무법인 수성 검토 완료)

### 3. 보조 시스템
- 사업자 인증 (국세청 API)
- 이메일 아웃리치 (Resend)
- 푸시 알림 (Firebase)
- 모바일 앱 (Capacitor)

---

## 📁 프로젝트 구조

```
k-alba-final/
├── app/                              # Next.js App Router
│   ├── page.jsx                      # 홈 (랜딩)
│   ├── about/                        # 회사 소개
│   ├── login/, signup/, profile/     # 인증
│   ├── jobs/                         # 알바 검색/지도/상세
│   │   ├── [id]/                     # 일자리 상세
│   │   ├── map/                      # 지도 검색
│   │   └── post/                     # 사장님 등록
│   ├── applicants/                   # 지원자 관리
│   ├── chat/                         # 채팅
│   ├── contracts/                    # 표준근로계약서
│   │   ├── new/, [id]/
│   ├── my/                           # 내 정보
│   │   ├── applications/, contracts/, jobs/
│   ├── partwork/                     # 외국인 유학생 시간제취업
│   │   ├── apply/                    # 학생용 신청서 작성
│   │   └── [id]/                     # 신청 상세
│   ├── staff/                        # 국제처 담당자 포털 ⭐
│   │   ├── partwork/                 # /staff/partwork - 대시보드
│   │   │   ├── [id]/                 # 신청 검토 + 서명
│   │   │   ├── profile/              # 담당자 설정
│   │   │   └── invite/               # 동료 초대
│   │   └── register/                 # 첫 admin 신청
│   ├── invite/accept/                # 초대 수락
│   ├── admin/                        # 운영 관리자
│   │   ├── campaigns/                # 이메일 캠페인
│   │   └── sync/                     # WorkNet/AgriWork 동기화
│   ├── simulator/                    # 인앱 시뮬레이터
│   └── api/                          # API 라우트
│       ├── geocode/, geocode/reverse/
│       ├── directions/, last-transit/
│       ├── jobs/notify-nearby/
│       ├── contract/generate-pdf/, contract/sign/
│       ├── partwork/apply/, partwork/upload/
│       │   └── generate-confirmation/
│       ├── email/send-campaign/, track-open/, unsubscribe/
│       └── staff/invitations/send/
├── components/                       # 재사용 UI 컴포넌트
│   ├── NavBar, Footer, KakaoMap, AddressSearch
│   ├── FileUpload, SignaturePad, NotificationBell
│   └── LocationPicker, RouteCard, LastTransitCard
├── lib/                              # 라이브러리/유틸
│   ├── supabase.js                   # Supabase 클라이언트
│   ├── theme.js                      # 디자인 토큰
│   ├── geolocation.ts                # 좌표/거리 계산
│   ├── email-templates.ts            # 이메일 템플릿
│   ├── pushNotifications.ts          # FCM 헬퍼
│   ├── locations-locale.js           # 17개 시도 한글-영문
│   └── metadata.js                   # SEO 메타
├── hooks/                            # React Hooks
│   ├── useNearbyJobs.js              # 위치 기반 일자리
│   └── useRecommendedJobs.js         # 비자/이력 기반 추천
├── scripts/                          # 운영 스크립트
│   └── backfill-geocodes.js          # 좌표 미보유 일자리 일괄 처리
├── supabase/migrations/              # DB 마이그레이션 (실행 순서)
│   ├── 20260101_001_visa_types.sql
│   ├── 20260201_001_geolocation.sql
│   ├── 20260301_001_recommendations.sql
│   ├── 20260315_001_push_notifications.sql
│   ├── 20260401_001_email_outreach.sql
│   ├── 20260410_001_partwork.sql
│   ├── 20260415_001_signatures.sql
│   ├── 20260420_001_partwork_documents.sql
│   ├── 20260423_001_user_profile.sql
│   ├── 20260425_001_staff_portal.sql           ⭐ 담당자 포털
│   └── 20260426_001_staff_verification.sql     ⭐ 검증 강화
├── public/simulator/                 # 정적 시뮬레이터
│   └── staff-simulator.html          # 담당자 시뮬레이터 (단독)
├── docs/                             # 문서
│   ├── 01_README.md                  # 일반 README
│   ├── 02_DESIGN_SYSTEM.md           # 디자인 시스템
│   ├── 03_LOCATION_SERVICE.md        # 위치 서비스 설계
│   ├── 04_CAPACITOR_MOBILE.md        # 모바일 앱
│   ├── 05_FIREBASE_PUSH.md           # 푸시 알림
│   ├── 06_BUGFIX_HISTORY.md          # 버그 수정 이력
│   ├── 07_PROJECT_REPORT.md          # 프로젝트 보고서
│   ├── 08_WIREFRAME_PATCHES.md       # 와이어프레임 패치
│   ├── 09_staff-manual.pdf           # 담당자 매뉴얼 (인쇄용, 20p)
│   ├── 09_staff-manual.docx          # 담당자 매뉴얼 (편집용)
│   └── 10_OPERATIONS_GUIDE.md        # 운영팀 가이드
├── app/sitemap.ts, robots.ts, globals.css
├── next.config.js                    # Next.js 설정
├── capacitor.config.ts               # 모바일 앱 설정
└── README.md                         # 이 파일
```

---

## 📊 시스템 통계

| 항목 | 수치 |
|---|---|
| **총 파일** | 93개 |
| **페이지** | 29개 (학생 측 + 담당자 측 + 관리자) |
| **API 라우트** | 14개 |
| **컴포넌트** | 12개 |
| **유틸/라이브러리** | 9개 |
| **DB 마이그레이션** | 11개 |
| **JSX/TSX 코드** | 17,121줄 |
| **TS/JS 코드** | 5,634줄 |
| **SQL 코드** | 2,054줄 |
| **CSS** | 111줄 |
| **총 코드** | **약 25,000줄** |
| **문서** | 11개 (디자인·인프라·매뉴얼·운영가이드) |

---

## 🚀 배포 절차

### 0단계: 프로젝트 클론
```bash
git clone https://github.com/MIRIM-MEDIA-LAB/k-alba.git
cd k-alba
```

### 1단계: 의존성 설치
```bash
npm install
# 또는
pnpm install
```

### 2단계: 환경변수 설정 (`.env.local`)
```bash
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJxxx
SUPABASE_SERVICE_ROLE_KEY=eyJxxx

# Kakao
KAKAO_REST_API_KEY=xxx
NEXT_PUBLIC_KAKAO_MAP_JS_KEY=xxx

# Tmap (대중교통 길찾기)
TMAP_APP_KEY=xxx

# Resend (이메일)
RESEND_API_KEY=re_xxx

# Firebase (푸시 알림)
FIREBASE_SERVER_KEY=xxx

# 사이트 URL
NEXT_PUBLIC_SITE_URL=https://k-alba.kr
INTERNAL_API_KEY=xxx
```

### 3단계: 데이터베이스 마이그레이션
```bash
# Supabase CLI로
supabase db push

# 또는 SQL Editor에서 supabase/migrations/ 폴더의 11개 파일을
# 파일명 순서대로 직접 실행
```

### 4단계: Supabase Storage 버킷 생성
- `staff-documents` (담당자 등록 자료, private)
- `partwork-documents` (학생 첨부 서류, private)
- `contract-pdfs` (서명된 계약서, private)
- `signatures` (디지털 서명 이미지, private)

### 5단계: 빌드 + 배포
```bash
npm run build
# Vercel 자동 배포 (git push로 트리거)
git push origin main
```

### 6단계: 모바일 앱 (선택)
```bash
npm run capacitor:sync
npx cap open ios     # iOS 시뮬레이터
npx cap open android # Android Studio
```

자세한 절차는 `docs/04_CAPACITOR_MOBILE.md` 참조

---

## 🏗 주요 시스템 모듈

### A. 알바 매칭 플랫폼
**핵심 페이지**: `/jobs`, `/jobs/[id]`, `/jobs/map`, `/jobs/post`
**API**: 지오코딩, 길찾기, 막차 시간, 알림
**DB**: `jobs`, `employers`, `job_sources`, `job_translations`, `applications`
**기능**:
- 검색·지도 검색 (반경/시군구/직종 필터)
- 추천 (비자 자격 + 거리 + 이력)
- 사장님 등록 (국세청 사업자 인증 + 카카오 주소 검색)
- 카카오톡 알림 (대량 발송)

### B. 학생 측 시간제취업 시스템
**핵심 페이지**: `/partwork/apply`
**API**: 신청 제출, 자동 확인서 생성, 파일 업로드
**DB**: `partwork_applications`, `universities`
**기능**:
- 단계형 신청서 (S0~S5: 정보·서류·검토)
- 7종 서류 업로드 (계약서·확인서·재학·성적·TOPIK·여권·외국인등록증)
- 6종은 카메라/파일, 2종은 자동 생성
- 시간제취업확인서 자동 작성 (회원정보 자동 채움)

### C. 국제처 담당자 포털 ⭐ (이번 세션 주요 작업)
**핵심 페이지**: `/staff/partwork`, `/staff/register`
**API**: 초대 발송
**DB**: `university_staff`, `partwork_review_log`, `staff_invitations`,
       `staff_registrations`, `staff_misconduct_reports`
**기능**:
- 4단계 처리 워크플로 (제출 → 추가서류요청 / 반려 / 승인)
- Canvas 디지털 서명 (1회 등록 후 모든 신청서에 자동 사용)
- 한글 시간제취업확인서 자동 삽입 + PDF 출력
- 6가지 검증 메커니즘 (도메인·공문·통화·직원증·자가승인 차단·감사로그)
- 첫 admin 등록 신청 → 운영팀 5단계 검증 → 활성화
- 동료 초대 (학교 도메인 자동 검증)
- 기간 필터 + 검색 + 통계 카드
- 출입국관리법 자동 적용 (TOPIK + 인증대학 보너스)

### D. 운영 관리자
**핵심 페이지**: `/admin`, `/admin/campaigns`, `/admin/sync`
**기능**:
- WorkNet/AgriWork 일자리 동기화
- 이메일 캠페인 관리
- 시스템 모니터링

---

## 🛡 보안 모델

### Row Level Security (RLS)
- **학생**: 본인 신청서만 조회/수정
- **담당자**: 자기 대학 학생 신청서만 조회/수정
- **본인 신청 처리 차단**: 담당자가 본인 명의 신청은 처리 불가
- **관리자**: service_role로만 접근

### 데이터 격리
- 한양대 담당자가 SQL 직접 실행해도 한양대 데이터만 반환
- 도메인 검증 트리거로 application 코드 우회 차단
- 감사 로그 APPEND ONLY (수정/삭제 트리거 차단)

### 검증 시스템
- 학교 공식 도메인 화이트리스트
- 첫 admin은 공문 + 학교 사무실 통화 + 직원증 + 홈페이지 정보 일치 확인
- 정기 재검증 (1년 자동 만료 계산)
- 이상 활동 감지 뷰 (일괄 처리 / 새벽 시간)

---

## 🧪 테스트 / 시연

### 시뮬레이터로 즉시 체험
1. `public/simulator/staff-simulator.html`을 더블클릭으로 실행
2. 5개 탭 (대시보드 / 상세 / 담당자 설정 / 초대 / 신규 대학 등록)
3. 8건 모의 신청서로 워크플로 체험
4. Canvas 서명 + 한글 시간제취업확인서 생성

### 운영 환경 테스트
1. 마이그레이션 실행
2. 한양대 도메인 등록
3. 테스트 admin 생성
4. 학생 계정으로 신청서 제출 → 담당자 계정으로 검토

---

## 📚 문서 가이드

| 파일 | 대상 | 내용 |
|---|---|---|
| `docs/01_README.md` | 개발자 | 일반 README (개발 시작) |
| `docs/02_DESIGN_SYSTEM.md` | 디자이너/개발자 | 컬러·타입·간격 토큰 |
| `docs/03_LOCATION_SERVICE.md` | 개발자 | 지오코딩·길찾기 설계 |
| `docs/04_CAPACITOR_MOBILE.md` | 개발자 | iOS/Android 빌드 |
| `docs/05_FIREBASE_PUSH.md` | 개발자 | FCM 푸시 알림 |
| `docs/06_BUGFIX_HISTORY.md` | 개발자/QA | 버그 수정 이력 |
| `docs/07_PROJECT_REPORT.md` | 경영진 | 프로젝트 종합 보고 |
| `docs/08_WIREFRAME_PATCHES.md` | 디자이너 | 와이어프레임 변경점 |
| `docs/09_staff-manual.pdf` | 국제처 담당자 | 매뉴얼 (20p) — 인쇄·배포 |
| `docs/09_staff-manual.docx` | 국제처 담당자 | 매뉴얼 편집본 — 대학별 커스터마이징 |
| `docs/10_OPERATIONS_GUIDE.md` | K-ALBA 운영팀 | 등록 신청 검증 절차 + SQL 단축명령 |

---

## 🆘 문의

- 시스템 장애: support@k-alba.kr
- 기능 개선 제안: feedback@k-alba.kr
- 사업 협의: contact@k-alba.kr

운영사: **미림미디어랩 주식회사** · 대표 남기환
도메인: [k-alba.kr](https://k-alba.kr) · [partwork.k-alba.kr](https://k-alba.kr/partwork)

---

## 📝 변경 이력

### v1.0 — 2026-04-26 (이번 빌드)
- 국제처 담당자 포털 신규 구축 (5개 페이지 + 1 API + 2 마이그레이션)
- 6가지 검증 메커니즘 통합 (도메인/공문/통화/직원증/자가승인/감사로그)
- 4단계 워크플로 (제출/추가서류/반려/승인)
- 학교 도메인 자동 검증 + 자가 승인 차단 RLS
- 출입국관리법 시행령 자동 적용 (허용시간 vs 신청시간 비교 카드)
- 기간 필터 + 검색 추가
- 한글 시간제취업확인서 자동 생성 (붙임 4-1 양식)
- 매뉴얼 20페이지 + 시뮬레이터 + 운영 가이드 작성

### 이전 마일스톤
- v0.9: PartWork 학생 측 시스템 + 7종 서류 업로드
- v0.8: 사장님용 사업자 인증 (국세청 API)
- v0.7: 위치 서비스 + 길찾기 + 막차 시간
- v0.6: WorkNet/AgriWork 통합 + 이메일 아웃리치
- v0.5: 카카오톡 챗봇 연동 (계약서 자동 생성)
- v0.4: 모바일 앱 (Capacitor) + 푸시 알림 (Firebase)
- v0.1~v0.3: 기본 알바 매칭 + 다국어 + Vercel 배포

---

🇰🇷 Made with care for foreign workers and students in Korea.
